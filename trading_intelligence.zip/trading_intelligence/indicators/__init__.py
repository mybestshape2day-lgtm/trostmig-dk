"""Indicators module - tekniske indikatorer"""
from .technical import TechnicalIndicators
