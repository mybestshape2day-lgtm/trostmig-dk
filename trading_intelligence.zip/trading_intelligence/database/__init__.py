"""Database module - SQLite data lagring"""
from .db_manager import DatabaseManager
