"""Config module - centrale indstillinger"""
from .settings import SYMBOLS, INDICATORS, DATA, DB_PATH, DATA_DIR, BASE_DIR
