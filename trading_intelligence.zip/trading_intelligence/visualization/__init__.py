"""Visualization module - charts og plots"""
from .charts import ChartGenerator
